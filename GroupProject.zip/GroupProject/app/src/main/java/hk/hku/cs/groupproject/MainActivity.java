package hk.hku.cs.groupproject;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.SparseArray;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.apache.http.NameValuePair;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.ProtocolException;
import java.net.SocketException;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static android.provider.ContactsContract.CommonDataKinds.Website.URL;
import static java.net.Proxy.Type.HTTP;

public class MainActivity extends AppCompatActivity {
    private static final String DEBUG_TAG = "HttpExample";
    private TextView mTextMessage;
    private ListView listView;
//    private SimpleAdapter simpleAdapter;
    private TypeAdapter typeAdapter;
    private ArrayList<Map<String, Object>> news = new ArrayList<Map<String, Object>>();
    private ArrayList<Map<String, Object>> search = new ArrayList<Map<String, Object>>();
    private String addr;
    private SearchView searchView;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_subscribe:
                    mTextMessage.setText(R.string.title_subscribe);
                    return true;
                case R.id.navigation_note:
                    mTextMessage.setText(R.string.title_note);
                    return true;
                case R.id.navigation_setting:
                    mTextMessage.setText(R.string.title_setting);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // navigation view
//        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        navigation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()){
                    case R.id.navigation_home:
                        searchView.setVisibility(View.VISIBLE);
                    case R.id.navigation_subscribe:
                        System.out.println("Subscribe");
                        searchView.setVisibility((View.GONE));
                    case R.id.navigation_note:
                        searchView.setVisibility((View.GONE));
                    case R.id.navigation_setting:
                        searchView.setVisibility((View.GONE));
                }
            }
        });

        // set list view
        setContentView(R.layout.activity_main);
        listView = (ListView)this.findViewById(R.id.list_view);
        Thread thread = new Thread(networkTask);
        thread.start();
        typeAdapter = new TypeAdapter(this, news);
        listView.setAdapter(typeAdapter);

        // search view
        searchView = (SearchView) findViewById(R.id.search);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                Thread thread_search = new Thread(runnable_search);
                thread_search.start();
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                Message msg = new Message();
                Bundle data = new Bundle();
                data.putString("returnType", "all");
                msg.setData(data);
                handler.sendMessage(msg);
                return true;
            }
        });
    }

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            Bundle data = msg.getData();
            String val = data.getString("returnType");
            Log.i("mylog", "请求结果为-->" + val);
            // UI界面的更新等相关操作
            if(val == "all"){
                typeAdapter.ls = news;
            }else if(val == "search"){
                typeAdapter.ls = search;
            }
//            System.out.println(news);

//            listView.setAdapter(typeAdapter);
            typeAdapter.notifyDataSetChanged();
        }
    };


    Runnable networkTask = new Runnable() {
        @Override
        public void run() {
            addr = "http://10.0.2.2:5000/news";
            httpClient client = new httpClient();
            try {
                // news
                List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
                urlParameters.add(new BasicNameValuePair("posttype", "2"));//get all news
                news = client.NewsList("news", urlParameters);
//                System.out.println(news);

                // publisher
                List<NameValuePair> urlParameters1 = new ArrayList<NameValuePair>();
                urlParameters1.add(new BasicNameValuePair("posttype", "0"));//get all news
                urlParameters1.add(new BasicNameValuePair("userid", "10"));//get all news
                List<String> publisher = client.PublisherList("subscribe", urlParameters1);

                List<String> publisher2 = client.GetPublisher();

                Message msg = new Message();
                Bundle data = new Bundle();
                data.putString("returnType", "all");
                msg.setData(data);
                handler.sendMessage(msg);
            }catch (Exception e) {
                System.out.println("Error:"+e);
            }
        }
    };

    Runnable runnable_search = new Runnable() {
        private  String keyword;

        public void setKeyword(String keyword) {
            this.keyword = keyword;
        }

        @Override
        public void run() {
            addr = "http://10.0.2.2:5000/news";
            httpClient client = new httpClient();
            try {
                // news
                List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
                urlParameters.add(new BasicNameValuePair("posttype", "1"));
                urlParameters.add(new BasicNameValuePair("keyword", keyword));
                search = client.NewsList("news", urlParameters);

                Message msg = new Message();
                Bundle data = new Bundle();
                data.putString("returnType", "search");
                msg.setData(data);
                handler.sendMessage(msg);
            }catch (Exception e) {
                System.out.println("Error:"+e);
            }
        }
    };
}
