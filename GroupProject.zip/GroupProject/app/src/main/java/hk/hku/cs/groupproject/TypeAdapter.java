package hk.hku.cs.groupproject;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TypeAdapter extends BaseAdapter {

    ArrayList<Map<String, Object>> ls;
    Context mContext;
    LinearLayout linearLayout = null;
    LayoutInflater inflater;
    TextView tex;
    String image_url;
    final int VIEW_TYPE = 2;
    final int TYPE_1 = 0;
    final int TYPE_2 = 1;

    public TypeAdapter(Context context, ArrayList<Map<String, Object>> list) {
        ls = list;
        mContext = context;
    }

    @Override
    public int getCount() {
        return ls.size();
    }

    @Override
    public Object getItem(int position) {
        return ls.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    // 每个convert view都会调用此方法，获得当前所需要的view样式
    // position is the flag of view type
    @Override
    public int getItemViewType(int position) {
        String test = ls.get(position).get("content").toString();
        if(test.contains("image")){
            String[] test_list = test.split("\"");
            for(int i = 0; i < test_list.length; i++){
                if(test_list[i].contains("http")){
                    image_url = test_list[i];
                    return TYPE_2;
                }
            }
        }
        image_url = "";
        return TYPE_1;
    }

    @Override
    public int getViewTypeCount() {
        return 2;
    }

    // position is the view type
    // convertView is the flexible view
    // parent is the parent of the current view
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder1 holder1 = null;
        ViewHolder2 holder2 = null;
        int type = getItemViewType(position); //get the type of view
        if (convertView == null) { // if there is no view
            inflater = LayoutInflater.from(mContext);
            // 按当前所需的样式，确定new的布局
            switch (type) {
                case TYPE_1:
                    // set view
                    convertView = inflater.inflate(R.layout.text_news, parent, false);
                    // set content of the view
                    holder1 = new ViewHolder1();
                    holder1.news_title = (TextView) convertView.findViewById(R.id.news_title);
                    holder1.news_publisher = (TextView) convertView.findViewById(R.id.news_publisher);
                    holder1.news_author = (TextView) convertView.findViewById(R.id.news_author);
                    holder1.news_time = (TextView) convertView.findViewById(R.id.news_time);
                    holder1.like = (TextView) convertView.findViewById(R.id.like_num);
                    holder1.dislike = (TextView) convertView.findViewById(R.id.dislike_num);
                    convertView.setTag(holder1);
                    break;
                case TYPE_2:
                    // set view
                    convertView = inflater.inflate(R.layout.image_news, parent, false);
                    // set content of the view
                    holder2 = new ViewHolder2();
                    holder2.news_image = (ImageView) convertView.findViewById(R.id.news2_image);
                    holder2.news_title = (TextView) convertView.findViewById(R.id.news2_title);
                    holder2.news_publisher = (TextView) convertView.findViewById(R.id.news2_publisher);
                    holder2.news_author = (TextView) convertView.findViewById(R.id.news2_author);
                    holder2.news_time = (TextView) convertView.findViewById(R.id.news2_time);
                    holder2.like = (TextView) convertView.findViewById(R.id.like_num2);
                    holder2.dislike = (TextView) convertView.findViewById(R.id.dislike_num2);
                    convertView.setTag(holder2);
                    break;
                default:
                    break;
            }

        } else {// get the original view
            switch (type) {
                case TYPE_1:
                    holder1 = (ViewHolder1) convertView.getTag();
                    break;
                case TYPE_2:
                    holder2 = (ViewHolder2) convertView.getTag();
                    break;
            }
        }
        // 设置资源
        switch (type) {
            case TYPE_1:
                holder1.news_title.setText(ls.get(position).get("title").toString());
                holder1.news_publisher.setText("Publisher: "+ls.get(position).get("publisher").toString());
                holder1.news_author.setText("Author: "+ls.get(position).get("author").toString());
                holder1.news_time.setText(ls.get(position).get("time").toString());
                holder1.like.setText("Like: "+ls.get(position).get("like_num").toString());
                holder1.dislike.setText("Dislike: "+ls.get(position).get("dislike_num").toString());
                break;
            case TYPE_2:
                holder2.news_image.setImageURI(Uri.fromFile(new File(image_url)));
                holder2.news_title.setText(ls.get(position).get("title").toString());
                holder2.news_publisher.setText(ls.get(position).get("publisher").toString());
                holder2.news_author.setText(ls.get(position).get("author").toString());
                holder2.news_time.setText(ls.get(position).get("time").toString());
                holder2.like.setText("Like: "+ls.get(position).get("like_num").toString());
                holder2.dislike.setText("Dislike: "+ls.get(position).get("dislike_num").toString());
                break;
        }

        return convertView;
    }


    public class ViewHolder1 {
        TextView news_title;
        TextView news_publisher;
        TextView news_author;
        TextView news_time;
        TextView like;
        TextView dislike;
    }

    public class ViewHolder2 {
        ImageView news_image;
        TextView news_title;
        TextView news_publisher;
        TextView news_author;
        TextView news_time;
        TextView like;
        TextView dislike;
    }
}