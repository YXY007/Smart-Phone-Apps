package hk.hku.cs.msc;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    HorizontalScrollView horizontalScrollView;
    private ViewPager viewPager;
    ListView listView_text, listView_image;
    ArrayList<Map<String, Object>> list;
    ArrayList<Map<String, Object>> list_img;
    SimpleAdapter adapter, adapter_img;
    LinearLayout lv_img;
    int click;
    int[] img_id;
    int[] stu_id;
    TextView choose1, choose2, choose3, choose4, choose5, choose6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        init();
    }

    // initialize the items
    void init(){
        click = R.id.nav_home;

        choose1 = (TextView) findViewById(R.id.choose1);
        choose2 = (TextView) findViewById(R.id.choose2);
        choose3 = (TextView) findViewById(R.id.choose3);
        choose4 = (TextView) findViewById(R.id.choose4);
        choose5 = (TextView) findViewById(R.id.choose5);
        choose6 = (TextView) findViewById(R.id.choose6);
        choose1.setOnClickListener(myOnClickListenser);
        choose2.setOnClickListener(myOnClickListenser);
        choose3.setOnClickListener(myOnClickListenser);
        choose4.setOnClickListener(myOnClickListenser);
        choose5.setOnClickListener(myOnClickListenser);
        choose6.setOnClickListener(myOnClickListenser);

        listView_text = (ListView) findViewById(R.id.list_view_txt);
        listView_image =(ListView) findViewById(R.id.list_view_img);

        lv_img = (LinearLayout) findViewById(R.id.lv_img);

        horizontalScrollView = (HorizontalScrollView) findViewById(R.id.top);
        horizontalScrollView.setVisibility(View.GONE);

        // the first listview, containing title and content
        list = new ArrayList<Map<String, Object>>();
        list_img = new ArrayList<Map<String, Object>>();
        Map<String, Object> map = new HashMap<String, Object>();

        InputStream inputStream = getResources().openRawResource(R.raw.program);
        String program_text = getString(inputStream);
        map.put("list_title", "Programme Overview");
        map.put("list_content", program_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream inputStream2 = getResources().openRawResource(R.raw.admission);
        String admission_text = getString(inputStream2);
        map.put("list_title", "Admission 2019");
        map.put("list_content", admission_text);
        list.add(map);
        adapter = new SimpleAdapter(this, list, R.layout.list_view_text,
                new String[]{"list_title", "list_content"},
                new int[]{R.id.list_title, R.id.list_content});
        listView_text.setAdapter(adapter);

        // the second listview, with photo
        adapter_img = new SimpleAdapter(this, list_img, R.layout.list_view_image,
                new String[]{"list_img", "name", "university", "field"},
                new int[]{R.id.list_image, R.id.name, R.id.university, R.id.filed});
        listView_image.setAdapter(adapter_img);

        setImageID();
    }

    void setImageID(){
        // mipmap id for professors
        img_id = new int[]{
                R.mipmap.pro01, R.mipmap.pro02, R.mipmap.pro03, R.mipmap.pro04, R.mipmap.pro05,
                R.mipmap.pro06, R.mipmap.pro07, R.mipmap.pro08, R.mipmap.pro09, R.mipmap.pro10,
                R.mipmap.pro11, R.mipmap.pro12, R.mipmap.pro13, R.mipmap.pro14, R.mipmap.pro15,
                R.mipmap.pro16, R.mipmap.pro17, R.mipmap.pro18, R.mipmap.pro19, R.mipmap.pro20,
                R.mipmap.pro21, R.mipmap.pro22, R.mipmap.pro23, R.mipmap.pro24, R.mipmap.pro25,
                R.mipmap.pro26, R.mipmap.pro27, R.mipmap.pro28, R.mipmap.pro29
        };
        // mipmap id for students
        stu_id = new int[]{
                R.mipmap.stu01, R.mipmap.stu02, R.mipmap.stu03, R.mipmap.stu04, R.mipmap.stu05,
                R.mipmap.stu06, R.mipmap.stu07, R.mipmap.stu08, R.mipmap.stu09, R.mipmap.stu10
        };
    }

    // get text string from file
    public static String getString(InputStream inputStream) {
        InputStreamReader inputStreamReader = null;
        try {
            inputStreamReader = new InputStreamReader(inputStream, "gbk");
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }
        BufferedReader reader = new BufferedReader(inputStreamReader);
        StringBuffer sb = new StringBuffer("");
        String line;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                sb.append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

    // get a list of string
    public static ArrayList<String> getStrings(InputStream inputStream) {
        InputStreamReader inputStreamReader = null;
        try {
            inputStreamReader = new InputStreamReader(inputStream, "gbk");
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }
        BufferedReader reader = new BufferedReader(inputStreamReader);
        StringBuffer sb;
        String line;
        ArrayList<String> ret = new ArrayList<>();
        try {
            while ((line = reader.readLine()) != null) {
                sb = new StringBuffer("");
                sb.append(line);
                ret.add(sb.toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ret;
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            click = R.id.nav_home;
            Map<String, Object> map = new HashMap<String, Object>();

            list.clear();
            InputStream inputStream = getResources().openRawResource(R.raw.program);
            String program_text = getString(inputStream);
            map.put("list_title", "Programme Overview");
            map.put("list_content", program_text);
            list.add(map);

            map = new HashMap<String, Object>();
            InputStream inputStream2 = getResources().openRawResource(R.raw.admission);
            String admission_text = getString(inputStream2);
            map.put("list_title", "Admission 2019");
            map.put("list_content", admission_text);
            list.add(map);
            adapter.notifyDataSetChanged();

            list_img.clear();
            adapter_img.notifyDataSetChanged();

            horizontalScrollView.setVisibility(View.GONE);
        } else if (id == R.id.nav_about) {
            click = R.id.nav_about;
            choose1.setVisibility(View.VISIBLE);
            choose2.setVisibility(View.VISIBLE);
            choose3.setVisibility(View.VISIBLE);
            choose4.setVisibility(View.GONE);
            choose5.setVisibility(View.GONE);
            choose6.setVisibility(View.GONE);
            choose1.setText("Faculty");
            choose2.setText("Director's Message");
            choose3.setText("HKU");
            horizontalScrollView.setVisibility(View.VISIBLE);
            faculty();
        } else if (id == R.id.nav_admission) {
            click = R.id.nav_admission;
            choose1.setVisibility(View.VISIBLE);
            choose2.setVisibility(View.VISIBLE);
            choose3.setVisibility(View.VISIBLE);
            choose4.setVisibility(View.VISIBLE);
            choose5.setVisibility(View.VISIBLE);
            choose6.setVisibility(View.VISIBLE);
            choose1.setText("Requirements");
            choose2.setText("Procedures");
            choose3.setText("Fees");
            choose4.setText("Words from Students");
            choose5.setText("Information");
            choose6.setText("FAQ");
            horizontalScrollView.setVisibility(View.VISIBLE);
            requirement();
        } else if (id == R.id.nav_curriculum) {
            click = R.id.nav_curriculum;
            choose1.setVisibility(View.VISIBLE);
            choose2.setVisibility(View.VISIBLE);
            choose3.setVisibility(View.VISIBLE);
            choose4.setVisibility(View.VISIBLE);
            choose5.setVisibility(View.GONE);
            choose6.setVisibility(View.GONE);
            choose1.setText("Overview");
            choose2.setText("Courses");
            choose3.setText("Schedule");
            choose4.setText("Regulations");
            horizontalScrollView.setVisibility(View.VISIBLE);
            overview();
        } else if (id == R.id.nav_graduate) {
            click = R.id.nav_graduate;
            horizontalScrollView.setVisibility(View.GONE);
            alumni();
        } else if (id == R.id.nav_resource) {
            click = R.id.nav_resource;
            choose1.setVisibility(View.VISIBLE);
            choose2.setVisibility(View.VISIBLE);
            choose3.setVisibility(View.GONE);
            choose4.setVisibility(View.GONE);
            choose5.setVisibility(View.GONE);
            choose6.setVisibility(View.GONE);
            choose1.setText("Learning Environment");
            choose2.setText("Useful Links");
            horizontalScrollView.setVisibility(View.VISIBLE);
            environment();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

// About

    // Faculty
    void faculty(){
        choose1.setTextColor(getResources().getColor(R.color.colorBlack));
        choose2.setTextColor(getResources().getColor(R.color.colorGray));
        choose3.setTextColor(getResources().getColor(R.color.colorGray));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream inputStream = getResources().openRawResource(R.raw.faculty);
        String faculty_text = getString(inputStream);
        map.put("list_title", "Faculty");
        map.put("list_content", faculty_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        // read content from files
        InputStream iS_name = getResources().openRawResource(R.raw.professors_name);
        ArrayList<String> professors_name = getStrings(iS_name);
        InputStream iS_university = getResources().openRawResource(R.raw.professors_university);
        ArrayList<String> professors_university = getStrings(iS_university);
        InputStream iS_email = getResources().openRawResource(R.raw.professors_email);
        ArrayList<String> professors_email = getStrings(iS_email);
        InputStream iS_field = getResources().openRawResource(R.raw.professors_field);
        ArrayList<String> professors_field = getStrings(iS_field);

        list_img.clear();
        for(int i = 0; i < professors_name.size(); i++){
            map = new HashMap<>();
            map.put("list_img", img_id[i]);
            map.put("name", professors_name.get(i));
            map.put("university", professors_university.get(i));
            map.put("email", professors_email.get(i));
            map.put("field", professors_field.get(i));
            list_img.add(map);
        }
        adapter_img.notifyDataSetChanged();
    }

    // Message from Programme Director
    void message(){
        choose1.setTextColor(getResources().getColor(R.color.colorGray));
        choose2.setTextColor(getResources().getColor(R.color.colorBlack));
        choose3.setTextColor(getResources().getColor(R.color.colorGray));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream inputStream = getResources().openRawResource(R.raw.message);
        String message_text = getString(inputStream);
        map.put("list_title", "Message from Programme Director");
        map.put("list_content", message_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        list_img.clear();
        adapter_img.notifyDataSetChanged();
    }

    // About HKU
    void hku(){
        choose1.setTextColor(getResources().getColor(R.color.colorGray));
        choose2.setTextColor(getResources().getColor(R.color.colorGray));
        choose3.setTextColor(getResources().getColor(R.color.colorBlack));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream inputStream = getResources().openRawResource(R.raw.hku);
        String hku_text = getString(inputStream);
        map.put("list_title", "The University of Hong Kong");
        map.put("list_content", hku_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        list_img.clear();
        adapter_img.notifyDataSetChanged();
    }

//Admission

    // Admission Requirements
    void requirement(){
        choose1.setTextColor(getResources().getColor(R.color.colorBlack));
        choose2.setTextColor(getResources().getColor(R.color.colorGray));
        choose3.setTextColor(getResources().getColor(R.color.colorGray));
        choose4.setTextColor(getResources().getColor(R.color.colorGray));
        choose5.setTextColor(getResources().getColor(R.color.colorGray));
        choose6.setTextColor(getResources().getColor(R.color.colorGray));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream iS_eligibility = getResources().openRawResource(R.raw.eligibility);
        String eligibility_text = getString(iS_eligibility);
        map.put("list_title", "Eligibility");
        map.put("list_content", eligibility_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_regulations = getResources().openRawResource(R.raw.regulations);
        String regulations_text = getString(iS_regulations);
        map.put("list_title", "Regulations");
        map.put("list_content", regulations_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_requirement = getResources().openRawResource(R.raw.requirement);
        String requirement_text = getString(iS_requirement);
        map.put("list_title", "English Language Proficiency Requirement");
        map.put("list_content", requirement_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        list_img.clear();
        adapter_img.notifyDataSetChanged();
    }

    // pplication Procedures
    void procedure(){
        choose1.setTextColor(getResources().getColor(R.color.colorGray));
        choose2.setTextColor(getResources().getColor(R.color.colorBlack));
        choose3.setTextColor(getResources().getColor(R.color.colorGray));
        choose4.setTextColor(getResources().getColor(R.color.colorGray));
        choose5.setTextColor(getResources().getColor(R.color.colorGray));
        choose6.setTextColor(getResources().getColor(R.color.colorGray));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream iS_procedures = getResources().openRawResource(R.raw.procedures);
        String procedures_text = getString(iS_procedures);
        map.put("list_title", "Application Procedures");
        map.put("list_content", procedures_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_fee = getResources().openRawResource(R.raw.fee);
        String fee_text = getString(iS_fee);
        map.put("list_title", "Application Fee");
        map.put("list_content", fee_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_timetable = getResources().openRawResource(R.raw.timetable);
        String timetable_text = getString(iS_timetable);
        map.put("list_title", "Application Timetable");
        map.put("list_content", timetable_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        list_img.clear();
        adapter_img.notifyDataSetChanged();
    }

    // Composition Fees
    void fee(){
        choose1.setTextColor(getResources().getColor(R.color.colorGray));
        choose2.setTextColor(getResources().getColor(R.color.colorGray));
        choose3.setTextColor(getResources().getColor(R.color.colorBlack));
        choose4.setTextColor(getResources().getColor(R.color.colorGray));
        choose5.setTextColor(getResources().getColor(R.color.colorGray));
        choose6.setTextColor(getResources().getColor(R.color.colorGray));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream iS_fees = getResources().openRawResource(R.raw.fees);
        String fees_text = getString(iS_fees);
        map.put("list_title", "Composition Fees");
        map.put("list_content", fees_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_financial = getResources().openRawResource(R.raw.financial);
        String financial_text = getString(iS_financial);
        map.put("list_title", "Financial Assistance");
        map.put("list_content", financial_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        list_img.clear();
        adapter_img.notifyDataSetChanged();
    }

    // Words from Students and Graduates
    void words(){
        choose1.setTextColor(getResources().getColor(R.color.colorGray));
        choose2.setTextColor(getResources().getColor(R.color.colorGray));
        choose3.setTextColor(getResources().getColor(R.color.colorGray));
        choose4.setTextColor(getResources().getColor(R.color.colorBlack));
        choose5.setTextColor(getResources().getColor(R.color.colorGray));
        choose6.setTextColor(getResources().getColor(R.color.colorGray));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream iS_words = getResources().openRawResource(R.raw.words);
        String words_text = getString(iS_words);
        map.put("list_title", "Words from Students and Graduates");
        map.put("list_content", words_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        InputStream iS_name = getResources().openRawResource(R.raw.stu_name);
        ArrayList<String> professors_name = getStrings(iS_name);
        InputStream iS_university = getResources().openRawResource(R.raw.year);
        ArrayList<String> professors_university = getStrings(iS_university);
        InputStream iS_field = getResources().openRawResource(R.raw.stu_word);
        ArrayList<String> professors_field = getStrings(iS_field);

        list_img.clear();
        for(int i = 0; i < professors_name.size(); i++){
            map = new HashMap<>();
            map.put("list_img", stu_id[i]);
            map.put("name", professors_name.get(i));
            map.put("university", professors_university.get(i));
            map.put("email", "\n");
            map.put("field", professors_field.get(i));
            list_img.add(map);
        }
        adapter_img.notifyDataSetChanged();
    }

    // Information Sessions
    void information(){
        choose1.setTextColor(getResources().getColor(R.color.colorGray));
        choose2.setTextColor(getResources().getColor(R.color.colorGray));
        choose3.setTextColor(getResources().getColor(R.color.colorGray));
        choose4.setTextColor(getResources().getColor(R.color.colorGray));
        choose5.setTextColor(getResources().getColor(R.color.colorBlack));
        choose6.setTextColor(getResources().getColor(R.color.colorGray));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream iS_information = getResources().openRawResource(R.raw.information);
        String information_text = getString(iS_information);
        map.put("list_title", "Information Sessions");
        map.put("list_content", information_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        list_img.clear();
        adapter_img.notifyDataSetChanged();
    }

    // FAQ
    void faq(){
        choose1.setTextColor(getResources().getColor(R.color.colorGray));
        choose2.setTextColor(getResources().getColor(R.color.colorGray));
        choose3.setTextColor(getResources().getColor(R.color.colorGray));
        choose4.setTextColor(getResources().getColor(R.color.colorGray));
        choose5.setTextColor(getResources().getColor(R.color.colorGray));
        choose6.setTextColor(getResources().getColor(R.color.colorBlack));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream iS_admission_q = getResources().openRawResource(R.raw.admission_q);
        String admission_q_text = getString(iS_admission_q);
        map.put("list_title", "ADMISSIONS");
        map.put("list_content", admission_q_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_visa = getResources().openRawResource(R.raw.visa);
        String visa_text = getString(iS_visa);
        map.put("list_title", "VISA RELATED (NON-LOCAL APPLICANTS)");
        map.put("list_content", visa_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        list_img.clear();
        adapter_img.notifyDataSetChanged();
    }

    // rogramme Overview
    void overview(){
        choose1.setTextColor(getResources().getColor(R.color.colorBlack));
        choose2.setTextColor(getResources().getColor(R.color.colorGray));
        choose3.setTextColor(getResources().getColor(R.color.colorGray));
        choose4.setTextColor(getResources().getColor(R.color.colorGray));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream iS_overview = getResources().openRawResource(R.raw.overview);
        String overview_text = getString(iS_overview);
        map.put("list_title", "Programme Overview");
        map.put("list_content", overview_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_stream = getResources().openRawResource(R.raw.stream);
        String stream_text = getString(iS_stream);
        map.put("list_title", "Stream of Study");
        map.put("list_content", stream_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_pattern = getResources().openRawResource(R.raw.pattern);
        String pattern_text = getString(iS_pattern);
        map.put("list_title", "Pattern of Study");
        map.put("list_content", pattern_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_enrolment = getResources().openRawResource(R.raw.enrolment);
        String enrolment_text = getString(iS_enrolment);
        map.put("list_title", "Enrolment Mode");
        map.put("list_content", enrolment_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_selection = getResources().openRawResource(R.raw.selection);
        String selection_text = getString(iS_selection);
        map.put("list_title", "Selection of Courses");
        map.put("list_content", selection_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_capstone = getResources().openRawResource(R.raw.capstone);
        String capstone_text = getString(iS_capstone);
        map.put("list_title", "Capstone Experience – Dissertations and Projects");
        map.put("list_content", capstone_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        list_img.clear();
        adapter_img.notifyDataSetChanged();
    }

    // MSc(CompSc) Courses
    void courses(){
        choose1.setTextColor(getResources().getColor(R.color.colorGray));
        choose2.setTextColor(getResources().getColor(R.color.colorBlack));
        choose3.setTextColor(getResources().getColor(R.color.colorGray));
        choose4.setTextColor(getResources().getColor(R.color.colorGray));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream iS_courses = getResources().openRawResource(R.raw.courses);
        String courses_text = getString(iS_courses);
        map.put("list_title", "MSc(CompSc) Courses");
        map.put("list_content", courses_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        list_img.clear();
        adapter_img.notifyDataSetChanged();
    }

    // Duration of Study
    void duration(){
        choose1.setTextColor(getResources().getColor(R.color.colorGray));
        choose2.setTextColor(getResources().getColor(R.color.colorGray));
        choose3.setTextColor(getResources().getColor(R.color.colorBlack));
        choose4.setTextColor(getResources().getColor(R.color.colorGray));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream iS_duration = getResources().openRawResource(R.raw.duration);
        String duration_text = getString(iS_duration);
        map.put("list_title", "Duration of Study");
        map.put("list_content", duration_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_schedule = getResources().openRawResource(R.raw.schedule);
        String schedule_text = getString(iS_schedule);
        map.put("list_title", "Class Schedule");
        map.put("list_content", schedule_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        list_img.clear();
        adapter_img.notifyDataSetChanged();
    }

    // REGULATIONS
    void regulation(){
        choose1.setTextColor(getResources().getColor(R.color.colorGray));
        choose2.setTextColor(getResources().getColor(R.color.colorGray));
        choose3.setTextColor(getResources().getColor(R.color.colorGray));
        choose4.setTextColor(getResources().getColor(R.color.colorBlack));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream iS_regulation = getResources().openRawResource(R.raw.regulation);
        String regulation_text = getString(iS_regulation);
        map.put("list_title", "DREGULATIONS");
        map.put("list_content", regulation_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        list_img.clear();
        adapter_img.notifyDataSetChanged();
    }

    // MSc(CompSc) Alumni Association
    void alumni(){
        choose1.setTextColor(getResources().getColor(R.color.colorBlack));
        choose2.setTextColor(getResources().getColor(R.color.colorGray));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream iS_alumni = getResources().openRawResource(R.raw.alumni);
        String alumni_text = getString(iS_alumni);
        map.put("list_title", "MSc(CompSc) Alumni Association");
        map.put("list_content", alumni_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        list_img.clear();
        adapter_img.notifyDataSetChanged();
    }

    // Learning Environment
    void environment(){
        choose1.setTextColor(getResources().getColor(R.color.colorBlack));
        choose2.setTextColor(getResources().getColor(R.color.colorGray));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream iS_office = getResources().openRawResource(R.raw.office);
        String office_text = getString(iS_office);
        map.put("list_title", "MSc Programme Office");
        map.put("list_content", office_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_its = getResources().openRawResource(R.raw.its);
        String its_text = getString(iS_its);
        map.put("list_title", "ITS, Moodle and Panopto");
        map.put("list_content", its_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_association = getResources().openRawResource(R.raw.association);
        String association_text = getString(iS_association);
        map.put("list_title", "Student/Alumni Associations");
        map.put("list_content", association_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_research = getResources().openRawResource(R.raw.research);
        String research_text = getString(iS_research);
        map.put("list_title", "Research Groups and Centers");
        map.put("list_content", research_text);
        list.add(map);

        map = new HashMap<String, Object>();
        InputStream iS_service = getResources().openRawResource(R.raw.service);
        String service_text = getString(iS_service);
        map.put("list_title", "Other University Services");
        map.put("list_content", service_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        list_img.clear();
        adapter_img.notifyDataSetChanged();
    }

    // Useful Links
    void link(){
        choose1.setTextColor(getResources().getColor(R.color.colorGray));
        choose2.setTextColor(getResources().getColor(R.color.colorBlack));

        list.clear();
        Map<String, Object> map = new HashMap<String, Object>();
        InputStream iS_links = getResources().openRawResource(R.raw.links);
        String links_text = getString(iS_links);
        map.put("list_title", "Useful Links");
        map.put("list_content", links_text);
        list.add(map);
        adapter.notifyDataSetChanged();

        list_img.clear();
        adapter_img.notifyDataSetChanged();
    }

    private View.OnClickListener myOnClickListenser = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (click){
                case R.id.nav_about:
                    switch (v.getId()){
                        case R.id.choose1:
                            faculty();
                            break;
                        case R.id.choose2:
                            message();
                            break;
                        case R.id.choose3:
                            hku();
                            break;
                        default:
                            break;
                    }
                    break;
                case R.id.nav_admission:
                    switch (v.getId()){
                        case R.id.choose1:
                            requirement();
                            break;
                        case R.id.choose2:
                            procedure();
                            break;
                        case R.id.choose3:
                            fee();
                            break;
                        case R.id.choose4:
                            words();
                            break;
                        case R.id.choose5:
                            information();
                            break;
                        case R.id.choose6:
                            faq();
                            break;
                        default:
                            break;
                    }
                    break;
                case R.id.nav_curriculum:
                    switch (v.getId()){
                        case R.id.choose1:
                            overview();
                            break;
                        case R.id.choose2:
                            courses();
                            break;
                        case R.id.choose3:
                            duration();
                            break;
                        case R.id.choose4:
                            regulation();
                            break;
                        default:
                            break;
                    }
                    break;
                case R.id.nav_resource:
                    switch (v.getId()){
                        case R.id.choose1:
                            environment();
                            break;
                        case R.id.choose2:
                            link();
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
        }
    };
}
