package hk.hku.cs.news;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PublisherActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    private CheckBox checkBox;
    httpClient client;
    List<String> publishers, subscribes;
    String userID;
    ListView listView_publisher;
    private ArrayList<HashMap<String, Object>> mData;
    private ListView mListView;
    private MyAdapter mAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.publishers_list);
//        LinearLayout linearLayout = (LinearLayout) getLayoutInflater().inflate(
//                R.layout.publishers_list, null);
//        checkBox = (CheckBox) findViewById(R.id.checkbox);

        client = new httpClient();
        try {
            publishers = client.GetPublisher();
        }catch (Exception e){
            System.out.println(e);
        }

        SharedPreferences sharedPreferences=getSharedPreferences("login", MODE_PRIVATE);
        userID = sharedPreferences.getString("userid","-1");

        List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
        urlParameters.add(new BasicNameValuePair("posttype", "0"));
        urlParameters.add(new BasicNameValuePair("userid", userID));
        try{
            subscribes = client.PublisherList("subscribe", urlParameters);
        }catch (Exception e){
            System.out.println(e);
        }

        mListView = (ListView) findViewById(R.id.publisher_list);
        mListView.setOnItemClickListener(this);

        mData = new ArrayList<HashMap<String,Object>>();
        for (int i = 0; i < publishers.size(); i++) {
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("publisher", publishers.get(i));
            if(subscribes.contains(publishers.get(i)))
                map.put("check", true);
            else
                map.put("check", false);
            mData.add(map);
        }
        mAdapter = new MyAdapter(getApplicationContext(), mData);
        mListView.setAdapter(mAdapter);

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        HashMap<String, Object> item = mData.get(position);
        System.out.println(item);
        String name = (String) item.get("publisher");
        Boolean isChecked = (Boolean) item.get("check");
        item.put("check", !isChecked);

        List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
        urlParameters.add(new BasicNameValuePair("userid", userID));
        urlParameters.add(new BasicNameValuePair("publisherid", String.valueOf(position+1)));
        if (!isChecked) {
            urlParameters.add(new BasicNameValuePair("posttype", "1"));
            try{
                client.TrueFalse("subscribe", urlParameters);
            }catch (Exception e){
                System.out.println(e);
            }
        } else {
            urlParameters.add(new BasicNameValuePair("posttype", "2"));
            try{
                client.TrueFalse("subscribe", urlParameters);
            }catch (Exception e){
                System.out.println(e);
            }
        }
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        this.finish();
        return true;
    }

}
