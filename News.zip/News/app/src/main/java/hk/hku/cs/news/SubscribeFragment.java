package hk.hku.cs.news;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SubscribeFragment extends Fragment {
    private TypeAdapter typeAdapter;
    private ArrayList<Map<String, Object>> news;
    private ListView listView;
    private String userid;
    private List<String> publisher;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.subscribe_news, container, false);
        news = new ArrayList<Map<String, Object>>();
        listView = (ListView) view.findViewById(R.id.list_view_subscribe);
        userid = "-1";
        typeAdapter = new TypeAdapter(getActivity(), news);
        listView.setAdapter(typeAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent news_page_intent = new Intent(getContext(), NewsActivity.class);
                news_page_intent.putExtra("title", news.get(position).get("title").toString());
                news_page_intent.putExtra("publisher", news.get(position).get("publisher").toString());
                news_page_intent.putExtra("publisherID", news.get(position).get("publisherID").toString());
                news_page_intent.putExtra("author", news.get(position).get("author").toString());
                news_page_intent.putExtra("time", news.get(position).get("time").toString());
                news_page_intent.putExtra("content", news.get(position).get("content").toString());
                news_page_intent.putExtra("like_num", news.get(position).get("like_num").toString());
                news_page_intent.putExtra("dislike_num", news.get(position).get("dislike_num").toString());
                news_page_intent.putExtra("newsID", news.get(position).get("newsID").toString());
                news_page_intent.putExtra("userID", userid);
                startActivity(news_page_intent);
            }
        });
        return view;
    }

    public void setUserid(String user){
        userid = user;
    }

    public void setUI(){
        Thread thread = new Thread(networkTask);
        thread.start();
    }

    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            Bundle data = msg.getData();
            String val = data.getString("returnType");
            Log.i("mylog", "请求结果为-->" + val);
            typeAdapter.ls = news;
            typeAdapter.notifyDataSetChanged();
        }
    };


    Runnable networkTask = new Runnable() {
        @Override
        public void run() {
            httpClient client = new httpClient();
            try {
                List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
                urlParameters.add(new BasicNameValuePair("posttype", "0"));
                urlParameters.add(new BasicNameValuePair("userid", userid));
                publisher = client.PublisherList("subscribe", urlParameters);

                String publishers = "";
                for(int i = 0; i < publisher.size(); i++){
                    if(i != 0) publishers+= " ";
                    publishers += publisher.get(i);
                }
                // news
                urlParameters.clear();
                urlParameters.add(new BasicNameValuePair("posttype", "0"));
                urlParameters.add(new BasicNameValuePair("publisher", publishers));
                news = client.NewsList("news", urlParameters);

                Message msg = new Message();
                Bundle data = new Bundle();
                data.putString("returnType", "all");
                msg.setData(data);
                handler.sendMessage(msg);
            }catch (Exception e) {
                System.out.println("Error:"+e);
            }
        }
    };

}
