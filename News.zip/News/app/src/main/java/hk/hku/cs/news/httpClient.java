package hk.hku.cs.news;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class httpClient {
    private final String USER_AGENT = "Mozilla/5.0";
    private final String LOCAL_URL = "http://10.0.2.2:5000/";

    // HTTP GET请求
    public List<String> GetPublisher() throws Exception {
        String url = LOCAL_URL + "publisher";
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("GET");
        con.setRequestProperty("User-Agent", USER_AGENT);
        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        List<String> ret = new ArrayList<String>();
        String publisher = in.readLine();
        JSONObject json_publisher = new JSONObject(publisher);
        String publishers = json_publisher.getString("publisher");
        JSONArray publisherList = new JSONArray(publishers);
        for(int i = 0; i < publisherList.length(); i++){
            JSONObject tmp = (JSONObject)publisherList.get(i);
            ret.add(tmp.getString("publisherName"));
        }
        in.close();
        return ret;
    }

    // HTTP GET请求
    public ArrayList<Map<String, String>> GetComent(String FileName, List<NameValuePair> urlParameters) throws Exception {
        String url = LOCAL_URL + FileName;
        HttpClient client = new DefaultHttpClient();
        HttpPost post = new HttpPost(url);
        post.setHeader("User-Agent", USER_AGENT);
        post.setEntity(new UrlEncodedFormEntity(urlParameters));
        HttpResponse response = client.execute(post);
        BufferedReader in = new BufferedReader(
                new InputStreamReader(response.getEntity().getContent()));
        ArrayList<Map<String, String>> ret = new ArrayList<Map<String, String>>();
        String publisher = in.readLine();
        JSONObject json_publisher = new JSONObject(publisher);
        String returnCode = json_publisher.getString("returnCode");
        if(returnCode == "1"){
            String returnContent = json_publisher.getString("returnContent");
            JSONArray publisherList = new JSONArray(returnContent);
            for(int i = 0; i < publisherList.length(); i++){
                JSONObject tmp = (JSONObject)publisherList.get(i);
                Map<String, String> tmp_map = new HashMap<String, String>();
                tmp_map.put("newsID", tmp.getString("newsID"));
                tmp_map.put("comment", tmp.getString("comment"));
                tmp_map.put("username", tmp.getString("username"));
                tmp_map.put("userID", tmp.getString("userID"));
                ret.add(tmp_map);
            }
        }
        in.close();
        return ret;
    }

    // get true or false
    public Boolean TrueFalse(String FileName, List<NameValuePair> urlParameters) throws Exception {
        String url = LOCAL_URL + FileName;
        HttpClient client = new DefaultHttpClient();
        HttpPost post = new HttpPost(url);
        post.setHeader("User-Agent", USER_AGENT);
        post.setEntity(new UrlEncodedFormEntity(urlParameters));
        HttpResponse response = client.execute(post);
        BufferedReader rd = new BufferedReader(
                new InputStreamReader(response.getEntity().getContent()));
        StringBuffer result = new StringBuffer();
        String result_line = rd.readLine();
        JSONObject result_json = new JSONObject(result_line);

        if(result_json.getString("returnCode") == "1"){
            return true;
        }
        else{
            return false;
        }
    }

    // get userid
    public String userID(String FileName, List<NameValuePair> urlParameters) throws Exception {
        String url = LOCAL_URL + FileName;
        HttpClient client = new DefaultHttpClient();
        HttpPost post = new HttpPost(url);
        post.setHeader("User-Agent", USER_AGENT);
        post.setEntity(new UrlEncodedFormEntity(urlParameters));
        HttpResponse response = client.execute(post);
        BufferedReader rd = new BufferedReader(
                new InputStreamReader(response.getEntity().getContent()));
        StringBuffer result = new StringBuffer();
        String result_line = rd.readLine();
        JSONObject result_json = new JSONObject(result_line);

        if(result_json.getString("returnCode") == "1"){
            return result_json.getString("userID");
        }
        else{
            return "False";
        }
    }

    // return news list
    public ArrayList<Map<String, Object>> NewsList(String FileName, List<NameValuePair> urlParameters) throws Exception {
        String url = LOCAL_URL + FileName;
        HttpClient client = new DefaultHttpClient();
        HttpPost post = new HttpPost(url);
        post.setHeader("User-Agent", USER_AGENT);
        post.setEntity(new UrlEncodedFormEntity(urlParameters));
        HttpResponse response = client.execute(post);
        BufferedReader rd = new BufferedReader(
                new InputStreamReader(response.getEntity().getContent()));
        String result_line = rd.readLine();
        JSONObject result_json = new JSONObject(result_line);
        ArrayList<Map<String, Object>> ret = new ArrayList<Map<String, Object> >();
        if(result_json.getString("returnCode") == "1"){
            JSONArray content = result_json.getJSONArray("returnContent");
            for(int i = 0; i < content.length(); i++){
                HashMap<String, Object> tmp = new HashMap<String, Object>();
                JSONObject json_object = (JSONObject)content.get(i);
                tmp.put("newsID", json_object.getString("newsID"));
                tmp.put("publisher", json_object.getString("publisher"));
                tmp.put("publisherID", json_object.getString("publisherID"));
                tmp.put("title", json_object.getString("title"));
                tmp.put("author", json_object.getString("author"));
                tmp.put("time", json_object.getString("time"));
                tmp.put("content", json_object.getString("content"));
                tmp.put("like_num", json_object.getString("like_num"));
                tmp.put("dislike_num", json_object.getString("dislike_num"));
                if(json_object.isNull("thumbnail"));
                else
                    tmp.put("thumbnail", json_object.getString("thumbnail"));
                ret.add(tmp);
            }
        }
        return ret;

    }

    // return publisher list
    public List<String> PublisherList(String FileName, List<NameValuePair> urlParameters) throws Exception {
        String url = LOCAL_URL + FileName;
        HttpClient client = new DefaultHttpClient();
        HttpPost post = new HttpPost(url);
        post.setHeader("User-Agent", USER_AGENT);
        post.setEntity(new UrlEncodedFormEntity(urlParameters));
        HttpResponse response = client.execute(post);
        BufferedReader rd = new BufferedReader(
                new InputStreamReader(response.getEntity().getContent()));
        String result_line = rd.readLine();
        JSONObject result_json = new JSONObject(result_line);
        List<String> ret = new ArrayList<String>();
        if(result_json.getString("returnCode") == "1"){
            JSONObject content = result_json.getJSONObject("returnContent");
            String publisher = content.getString("publisher");
            String publishers[] = publisher.substring(1,publisher.length()-1).split(",");
            for(int i = 0; i < publishers.length; i++){
                ret.add(publishers[i].substring(1, publishers[i].length()-1));
            }
        }
        return ret;
    }

}
