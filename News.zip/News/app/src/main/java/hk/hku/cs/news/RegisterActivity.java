package hk.hku.cs.news;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

public class RegisterActivity extends Activity {
    String username, password;
    EditText user, pwd;
    Button register_btn;
    TextView back, register_fail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        init();
    }

    public void init(){
        user = (EditText) findViewById(R.id.username_register);
        pwd = (EditText) findViewById(R.id.password_register);
        register_btn = (Button) findViewById(R.id.register_btn);
        back = (TextView) findViewById(R.id.register_later);
        register_fail = (TextView) findViewById(R.id.register_fail);
        register_btn.setOnClickListener(mOnClickListener);
        back.setOnClickListener(mOnClickListener);
    }

    View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch(v.getId()){
                case R.id.register_btn:
                    username = user.getText().toString();
                    password = pwd.getText().toString();
                    Thread thread = new Thread(networkTask);
                    thread.start();
                    break;
                case R.id.register_later:
                    Intent intent = new Intent();
                    intent.putExtra("userID", "-1");
                    setResult(RESULT_OK,intent);
                    finish();
                    break;
                default:
                    break;
            }
        }
    };

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            Bundle data = msg.getData();
            String val = data.getString("return");
            if(val == "False"){
                register_fail.setVisibility(View.VISIBLE);
            }else{
                register_fail.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "Register succeeded",
                        Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    };


    Runnable networkTask = new Runnable() {
        @Override
        public void run() {
            httpClient client = new httpClient();
            try {
                // news
                List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
                urlParameters.add(new BasicNameValuePair("username", username));
                urlParameters.add(new BasicNameValuePair("password", password));
                Boolean ret = client.TrueFalse("logon", urlParameters);

                Message msg = new Message();
                Bundle data = new Bundle();
                if(ret){
                    String useid = client.userID("login", urlParameters);
                    data.putString("return", useid);
                }else{
                    data.putString("return", "False");
                }
                msg.setData(data);
                handler.sendMessage(msg);
            }catch (Exception e) {
                System.out.println("Error:"+e);
            }
        }
    };
}
