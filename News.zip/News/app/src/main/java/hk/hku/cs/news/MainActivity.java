package hk.hku.cs.news;

import android.annotation.SuppressLint;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.support.annotation.ColorRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.internal.BottomNavigationItemView;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.TypedValue;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView navigation;
    private ViewPager viewPager;
    private String userid, username;
    HomeFragment homeFragment;
    SubscribeFragment subscribeFragment;
    NoteFragment noteFragment;
    SettingFragment settingFragment;
    protected PreferenceUtils preferenceUtils;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            SharedPreferences sharedPreferences=getSharedPreferences("login", MODE_PRIVATE);
            userid = sharedPreferences.getString("userid","-1");
            username = sharedPreferences.getString("username","");
            switch (item.getItemId()) {
                case R.id.navigation_home:
//                    getActionBar().setTitle("Home");
                    homeFragment.setUserID(userid);
                    viewPager.setCurrentItem(0);
                    return true;
                case R.id.navigation_subscribe:
                    // if not login, login
                    // if already login, go straight to the subscribe
                    if(userid.contains("-1")){
                        viewPager.setCurrentItem(1);
                        Intent login_intent = new Intent(getBaseContext(), LoginActivity.class);
                        startActivityForResult(login_intent, 1);
                    }else{
//                        getActionBar().setTitle("Subscribe");
                        subscribeFragment.setUserid(userid);
                        subscribeFragment.setUI();
                        viewPager.setCurrentItem(1);
                    }
                    return true;
                case R.id.navigation_note:
                    if(userid.contains("-1")){
                        Intent login_intent = new Intent(getBaseContext(), LoginActivity.class);
                        startActivityForResult(login_intent, 1);
                    }else{
//                        getActionBar().setTitle("Save");
                        noteFragment.setUserid(userid);
                        noteFragment.setUI();
                        viewPager.setCurrentItem(2);
                    }
                    return true;
                case R.id.navigation_settings:
                    if(userid.contains("-1")){
                        Intent login_intent = new Intent(getBaseContext(), LoginActivity.class);
                        startActivityForResult(login_intent, 1);
                    }else{
//                        getActionBar().setTitle("Settings");
                        viewPager.setCurrentItem(3);
                        settingFragment.setUser(username);
                        settingFragment.setUsername();
                    }
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Resources.Theme theme = getApplication().getTheme();
        theme.applyStyle(R.style.BlueGreyTheme, false);
        setContentView(R.layout.activity_main);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

//        getActionBar().setTitle("Home");

        navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        SharedPreferences sharedPreferences=getSharedPreferences("login", MODE_PRIVATE);
        userid = sharedPreferences.getString("userid","-1");
        username = sharedPreferences.getString("username","");

        initView();

    }

    public void logout(){

        SharedPreferences.Editor editor=getSharedPreferences("login",MODE_PRIVATE).edit();
        editor.remove("userid");
        editor.remove("username");
        editor.commit();
        viewPager.setCurrentItem(0);
        navigation.getMenu().getItem(0).setChecked(true);
    }

    private void initView() {
        viewPager = (ViewPager) findViewById(R.id.view_pager);

        setupViewPager(viewPager);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                navigation.getMenu().getItem(position).setChecked(true);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void setupViewPager(ViewPager viewPager) {
        BottomAdapter adapter = new BottomAdapter(getSupportFragmentManager());
        homeFragment = new HomeFragment();
        homeFragment.setUserID(userid);
        adapter.addFragment(homeFragment);
        subscribeFragment = new SubscribeFragment();
        adapter.addFragment(subscribeFragment);
        noteFragment = new NoteFragment();
        adapter.addFragment(noteFragment);
        settingFragment = new SettingFragment();
        adapter.addFragment(settingFragment);
        viewPager.setAdapter(adapter);
    }

    @Override
    @SuppressLint("RestrictedApi")
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode==1 && resultCode == -1){
            System.out.println("redsultCode " + resultCode);
            String ret = data.getStringExtra("userID");
            ret.replaceAll(" ", "");
            System.out.println("UserID" + userid);
            if(ret.contains("-1")){
                viewPager.setCurrentItem(0);
                navigation.getMenu().getItem(0).setChecked(true);
            }else{
                userid = ret;
                username = data.getStringExtra("username");
                subscribeFragment.setUserid(userid);
                subscribeFragment.setUI();
                viewPager.setCurrentItem(1);
                navigation.getMenu().getItem(1).setChecked(true);
            }
        }
        else{
            viewPager.setCurrentItem(0);
            navigation.getMenu().getItem(0).setChecked(true);

        }
    }
}
