package hk.hku.cs.news;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NewsAdapter extends BaseAdapter {

    ArrayList<String> ls;
    Context mContext;
    LinearLayout linearLayout = null;
    LayoutInflater inflater;
    TextView tex;
    String image_url;
    Bitmap bitmap;
    final int VIEW_TYPE = 2;
    final int TYPE_1 = 0;
    final int TYPE_2 = 1;
    ViewHolder1 holder1;
    ViewHolder2 holder2;

    public NewsAdapter(Context context, ArrayList<String> list) {
        ls = list;
        mContext = context;
    }

    @Override
    public int getCount() {
        return ls.size();
    }

    @Override
    public Object getItem(int position) {
        return ls.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    // position is the flag of view type
    @Override
    public int getItemViewType(int position) {
        String test = ls.get(position);
        if(test.contains("http")){
            image_url = test;
            return TYPE_2;
        }
        image_url = "";
        return TYPE_1;
    }

    @Override
    public int getViewTypeCount() {
        return 2;
    }

    // position is the view type
    // convertView is the flexible view
    // parent is the parent of the current view
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        holder1 = null;
        holder2 = null;
        int type = getItemViewType(position); //get the type of view
        if (convertView == null) { // if there is no view
            inflater = LayoutInflater.from(mContext);
            // 按当前所需的样式，确定new的布局
            switch (type) {
                case TYPE_1:
                    // set view
                    convertView = inflater.inflate(R.layout.news_page_text, parent, false);
                    // set content of the view
                    holder1 = new ViewHolder1();
                    holder1.news_text = (TextView) convertView.findViewById(R.id.news_txt);
                    convertView.setTag(holder1);
                    break;
                case TYPE_2:
                    // set view
                    convertView = inflater.inflate(R.layout.news_page_img, parent, false);
                    // set content of the view
                    holder2 = new ViewHolder2();
                    holder2.news_image = (ImageView) convertView.findViewById(R.id.news_img);
                    convertView.setTag(holder2);
                    break;
                default:
                    break;
            }

        } else {// get the original view
            switch (type) {
                case TYPE_1:
                    holder1 = (ViewHolder1) convertView.getTag();
                    break;
                case TYPE_2:
                    holder2 = (ViewHolder2) convertView.getTag();
                    break;
            }
        }
        // 设置资源
        switch (type) {
            case TYPE_1:
                holder1.news_text.setText(ls.get(position));
                break;
            case TYPE_2:
                holder2.news_image.setImageBitmap(returnBitMap(image_url));
                break;
        }

        return convertView;
    }

    public Bitmap returnBitMap(String url) {
        URL myFileUrl = null;
        Bitmap bitmap = null;
        try {
            myFileUrl = new URL(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        try {
            HttpURLConnection conn = (HttpURLConnection) myFileUrl.openConnection();
            conn.setDoInput(true);
            conn.connect();
            InputStream is = conn.getInputStream();
            bitmap = BitmapFactory.decodeStream(is);
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bitmap;
    }


    public class ViewHolder1 {
        TextView news_text;
    }

    public class ViewHolder2 {
        ImageView news_image;
    }


}