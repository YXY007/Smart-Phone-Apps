package hk.hku.cs.news;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class NewsActivity extends AppCompatActivity {
    TextView title_main, publisher_main, author_main, time_main;
    ListView list_view_main, list_view_comment;
    ImageView comment_btn, save_btn, like_btn, dislike_btn;
    Boolean save_flag, like_flag, dislike_flag, subscribe_flag;
    String title, publisher, publisherID, author, time_published, content, like_num, dislike_num, newsID, userID, userName;
    EditText editComment;
    LinearLayout comment_bar;
    Button subscribe_btn;
    ArrayList<String> content_list;
    ArrayList<Map<String, String> > comment_list;
    private NewsAdapter newsAdapter;
    httpClient client;
    SimpleAdapter commentAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.news_comment);
        init();
        if(!userID.contains("-1"))
            initFlag();

        final Context context = this;
        list_view_comment.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                if(comment_list.get(position).get("username").equals(userName)){
                    final AlertDialog.Builder normalDialog =
                            new AlertDialog.Builder(context);
                    normalDialog.setTitle("Delete Comment");
                    normalDialog.setMessage("Do you want to delete this comment?");
                    normalDialog.setPositiveButton("Yes",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
                                    // delete comment
                                    urlParameters.add(new BasicNameValuePair("posttype", "0"));
                                    urlParameters.add(new BasicNameValuePair("userid", userID));
                                    urlParameters.add(new BasicNameValuePair("newsid", newsID));
                                    urlParameters.add(new BasicNameValuePair("comment", comment_list.get(position).get("comment")));
                                    try{
                                        boolean flag = client.TrueFalse("deleteComment", urlParameters);
                                        if(flag){
                                            Thread thread = new Thread(networkTask);
                                            thread.start();
                                        }
                                    }catch (Exception e){
                                        System.out.println(e);
                                    }
                                }
                            });
                    normalDialog.setNegativeButton("No",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    // show
                    normalDialog.show();
                }
                return true;
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        this.finish();
        return true;
    }

    public void init(){
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent news_intent = getIntent();
        title = news_intent.getStringExtra("title");
        publisher = news_intent.getStringExtra("publisher");
        publisherID = news_intent.getStringExtra("publisherID");
        author = news_intent.getStringExtra("author");
        time_published = news_intent.getStringExtra("time");
        content = news_intent.getStringExtra("content");
        like_num = news_intent.getStringExtra("like_num");
        dislike_num = news_intent.getStringExtra("dislike_num");
        newsID = news_intent.getStringExtra("newsID");

        SharedPreferences sharedPreferences=getSharedPreferences("login", MODE_PRIVATE);
        userID = sharedPreferences.getString("userid","-1");
        userName = sharedPreferences.getString("username","-1");

        title_main = (TextView) findViewById(R.id.title_main);
        publisher_main = (TextView) findViewById(R.id.publisher_main);
        author_main = (TextView) findViewById(R.id.author_main);
        time_main = (TextView) findViewById(R.id.time_main);
        list_view_main = (ListView) findViewById(R.id.list_view_main);
        list_view_comment = (ListView) findViewById(R.id.list_view_comment);
        comment_btn = (ImageView) findViewById(R.id.comment_btn);
        save_btn = (ImageView) findViewById(R.id.save_btn);
        like_btn = (ImageView) findViewById(R.id.like_btn);
        dislike_btn = (ImageView) findViewById(R.id.dislike_btn);
        editComment = (EditText) findViewById(R.id.edit_comment);
        comment_bar = (LinearLayout) findViewById(R.id.comment_bar);
        subscribe_btn = (Button) findViewById(R.id.subscribe_main);

        title_main.setText(title);
        publisher_main.setText("Publisher: "+publisher);
        author_main.setText("Author: "+author);
        time_main.setText(time_published);
        comment_btn.setOnClickListener(mOnClickListener);
        save_btn.setOnClickListener(mOnClickListener);
        like_btn.setOnClickListener(mOnClickListener);
        dislike_btn.setOnClickListener(mOnClickListener);
        subscribe_btn.setOnClickListener(mOnClickListener);

        if(userID.contains("-1")){
            comment_bar.setVisibility(View.GONE);
            subscribe_btn.setVisibility(View.GONE);
        }else{
            comment_bar.setVisibility(View.VISIBLE);
            subscribe_btn.setVisibility(View.VISIBLE);
        }

        content_list = new ArrayList<>();
        comment_list = new ArrayList<>();
        getContent();

        newsAdapter = new NewsAdapter(getBaseContext(), content_list);
        list_view_main.setAdapter(newsAdapter);

        Thread thread = new Thread(networkTask);
        thread.start();

        client = new httpClient();
    }

    public void initFlag(){
        List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
        // save
        urlParameters.add(new BasicNameValuePair("posttype", "2"));
        urlParameters.add(new BasicNameValuePair("userid", userID));
        urlParameters.add(new BasicNameValuePair("newsid", newsID));
        try{
            save_flag = client.TrueFalse("checkComment", urlParameters);
            if(save_flag){
                save_btn.setImageResource(R.mipmap.favorite1);
            }else{
                save_btn.setImageResource(R.mipmap.favorite);
            }
        }catch (Exception e){
            System.out.println(e);
        }

        // like
        urlParameters.clear();
        urlParameters.add(new BasicNameValuePair("posttype", "0"));
        urlParameters.add(new BasicNameValuePair("userid", userID));
        urlParameters.add(new BasicNameValuePair("newsid", newsID));
        try{
            like_flag = client.TrueFalse("checkComment", urlParameters);
            if(like_flag){
                like_btn.setImageResource(R.mipmap.thumbs_up_hand_symbol);
            }else{
                like_btn.setImageResource(R.mipmap.thumbs_up);
            }
        }catch (Exception e){
            System.out.println(e);
        }

        // dislike
        urlParameters.clear();
        urlParameters.add(new BasicNameValuePair("posttype", "1"));
        urlParameters.add(new BasicNameValuePair("userid", userID));
        urlParameters.add(new BasicNameValuePair("newsid", newsID));
        try{
            dislike_flag = client.TrueFalse("checkComment", urlParameters);
            if(dislike_flag){
                dislike_btn.setImageResource(R.mipmap.thumbs_down_silhouette);
            }else{
                dislike_btn.setImageResource(R.mipmap.thumb_down);
            }
        }catch (Exception e){
            System.out.println(e);
        }

        // subscribe
        System.out.println(publisher);
        System.out.println(publisherID);
        urlParameters.clear();
        urlParameters.add(new BasicNameValuePair("posttype", "3"));
        urlParameters.add(new BasicNameValuePair("userid", userID));
        urlParameters.add(new BasicNameValuePair("publisherid", publisherID));
        try{
            subscribe_flag = client.TrueFalse("checkComment", urlParameters);
            if(subscribe_flag){
                subscribe_btn.setText("unsubscribe");
                subscribe_btn.setTextColor(getResources().getColor(R.color.colorGray));
                subscribe_btn.setBackgroundDrawable(getResources().getDrawable(R.drawable.subscribe_button_gray));
            }else{
                subscribe_btn.setText("subscribe");
                subscribe_btn.setTextColor(getResources().getColor(R.color.colorDoderBlue));
                subscribe_btn.setBackgroundDrawable(getResources().getDrawable(R.drawable.subscribe_button));
            }
        }catch (Exception e){
            System.out.println(e);
        }
    }

    public View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
            urlParameters.add(new BasicNameValuePair("userid", userID));
            urlParameters.add(new BasicNameValuePair("newsid", newsID));
            switch (v.getId()){
                case R.id.comment_btn:
                    String comment_txt = editComment.getText().toString();
                    comment_txt = comment_txt.trim();
                    if(comment_txt == "") break;
                    urlParameters.add(new BasicNameValuePair("posttype", "0"));
                    urlParameters.add(new BasicNameValuePair("comment", comment_txt));
                    try{
                        boolean flag = client.TrueFalse("comment", urlParameters);
                        if(flag){
                            Thread thread = new Thread(networkTask);
                            thread.start();
                            editComment.setText("");
                            editComment.clearFocus();
                        }
                    }catch (Exception e){
                        System.out.println(e);
                    }
                    break;
                case R.id.save_btn:
                    urlParameters.add(new BasicNameValuePair("posttype", "3"));
                    try {
                        if(!save_flag){
                            boolean flag = client.TrueFalse("comment", urlParameters);
                            if(flag){
                                save_flag = true;
                                save_btn.setImageResource(R.mipmap.favorite1);
                            }
                        }else{
                            boolean flag = client.TrueFalse("deleteComment", urlParameters);
                            if(flag){
                                save_flag = false;
                                save_btn.setImageResource(R.mipmap.favorite);
                            }
                        }
                    }catch (Exception e){
                        System.out.println(e);
                    }
                    break;
                case R.id.like_btn:
                    urlParameters.add(new BasicNameValuePair("posttype", "1"));
                    try {
                        if(!like_flag){
                            boolean flag = client.TrueFalse("comment", urlParameters);
                            if(flag){
                                like_flag = true;
                                like_btn.setImageResource(R.mipmap.thumbs_up_hand_symbol);
                            }
                        }else{
                            boolean flag = client.TrueFalse("deleteComment", urlParameters);
                            if(flag){
                                like_flag = false;
                                like_btn.setImageResource(R.mipmap.thumbs_up);
                            }
                        }
                    }catch (Exception e){
                        System.out.println(e);
                    }
                    break;
                case R.id.dislike_btn:
                    urlParameters.add(new BasicNameValuePair("posttype", "2"));
                    try {
                        if(!dislike_flag){
                            boolean flag = client.TrueFalse("comment", urlParameters);
                            if(flag){
                                dislike_flag = true;
                                dislike_btn.setImageResource(R.mipmap.thumbs_down_silhouette);
                            }
                        }else{
                            boolean flag = client.TrueFalse("deleteComment", urlParameters);
                            if(flag){
                                dislike_flag = false;
                                dislike_btn.setImageResource(R.mipmap.thumb_down);
                            }
                        }
                    }catch (Exception e){
                        System.out.println(e);
                    }
                    break;
                case R.id.subscribe_main:
                    urlParameters.clear();
                    urlParameters.add(new BasicNameValuePair("userid", userID));
                    urlParameters.add(new BasicNameValuePair("publisherid", publisherID));
                    try {
                        if(!subscribe_flag){//subscribe
                            urlParameters.add(new BasicNameValuePair("posttype", "1"));
                            boolean flag = client.TrueFalse("subscribe", urlParameters);
                            if(flag){
                                subscribe_flag = true;
                                subscribe_btn.setText("unsubscrib");
                                subscribe_btn.setTextColor(getResources().getColor(R.color.colorGray));
                                subscribe_btn.setBackgroundDrawable(getResources().getDrawable(R.drawable.subscribe_button_gray));
                            }
                        }else{//unsubscribe
                            urlParameters.add(new BasicNameValuePair("posttype", "2"));
                            boolean flag = client.TrueFalse("subscribe", urlParameters);
                            if(flag){
                                subscribe_flag = false;
                                subscribe_btn.setText("subscribe");
                                subscribe_btn.setTextColor(getResources().getColor(R.color.colorDoderBlue));
                                subscribe_btn.setBackgroundDrawable(getResources().getDrawable(R.drawable.subscribe_button));
                            }
                        }
                    }catch (Exception e){
                        System.out.println(e);
                    }
                default:
                    break;
            }
        }
    };

    public void getContent(){
        content = content.substring(2, content.length()-2);
        content = content.replace("},{", "^");
        String [] contents = content.split("\\^");
        for(int i = 0; i < contents.length; i++){
            String tmp = "{" + contents[i] + "}";
//            System.out.println(tmp);
            try{
                JSONObject json_test = new JSONObject(tmp);
                content_list.add(json_test.getString("content"));
            }catch (Exception e){
                System.out.println(e);
            }
        }
    }

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            Bundle data = msg.getData();
            String val = data.getString("returnType");
            Log.i("mylog", "请求结果为-->" + val);

            String [] strings = {"username", "comment"};
            int [] ids = {R.id.comment_user, R.id.comment_content};
            commentAdapter = new SimpleAdapter(getBaseContext(), comment_list, R.layout.comment_list, strings, ids);
            list_view_comment.setAdapter(commentAdapter);
            commentAdapter.notifyDataSetChanged();
        }
    };


    Runnable networkTask = new Runnable() {
        @Override
        public void run() {
            httpClient client = new httpClient();
            try {
                // news
                List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
                urlParameters.add(new BasicNameValuePair("posttype", "0"));
                urlParameters.add(new BasicNameValuePair("newsid", newsID));
                comment_list = client.GetComent("getinfo", urlParameters);

                Message msg = new Message();
                Bundle data = new Bundle();
                data.putString("returnType", "comment");
                msg.setData(data);
                handler.sendMessage(msg);
            }catch (Exception e) {
                System.out.println("Error:"+e);
            }
        }
    };
}
