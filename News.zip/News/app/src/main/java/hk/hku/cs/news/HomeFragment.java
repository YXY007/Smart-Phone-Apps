package hk.hku.cs.news;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class HomeFragment extends Fragment {
    private TypeAdapter typeAdapter;
    private ArrayList<Map<String, Object>> news;
    private ArrayList<Map<String, Object>> search;
    private ListView listView;
    private SearchView searchView;
    private boolean flag;//true news false search
    private String userID;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view =  inflater.inflate(R.layout.news_fragment, container, false);
        news = new ArrayList<Map<String, Object>>();
        search  = new ArrayList<Map<String, Object>>();
        listView = (ListView) view.findViewById(R.id.list_view);
        Thread thread = new Thread(networkTask);
        thread.start();
        typeAdapter = new TypeAdapter(getActivity(), news);
        listView.setAdapter(typeAdapter);

        flag = true;

        // search view
        searchView = (SearchView) view.findViewById(R.id.search);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                Thread thread_search = new Thread(runnable_search);
                thread_search.start();
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                Message msg = new Message();
                Bundle data = new Bundle();
                data.putString("returnType", "all");
                msg.setData(data);
                handler.sendMessage(msg);
                return true;
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(flag){
                    Intent news_page_intent = new Intent(getContext(), NewsActivity.class);
                    news_page_intent.putExtra("title", news.get(position).get("title").toString());
                    news_page_intent.putExtra("publisher", news.get(position).get("publisher").toString());
                    news_page_intent.putExtra("publisherID", news.get(position).get("publisherID").toString());
                    news_page_intent.putExtra("author", news.get(position).get("author").toString());
                    news_page_intent.putExtra("time", news.get(position).get("time").toString());
                    news_page_intent.putExtra("content", news.get(position).get("content").toString());
                    news_page_intent.putExtra("like_num", news.get(position).get("like_num").toString());
                    news_page_intent.putExtra("dislike_num", news.get(position).get("dislike_num").toString());
                    news_page_intent.putExtra("newsID", news.get(position).get("newsID").toString());
                    news_page_intent.putExtra("userID", userID);
                    startActivity(news_page_intent);
                }else{
                    Intent news_page_intent = new Intent(getContext(), NewsActivity.class);
                    news_page_intent.putExtra("title", search.get(position).get("title").toString());
                    news_page_intent.putExtra("publisher", search.get(position).get("publisher").toString());
                    news_page_intent.putExtra("publisherID", search.get(position).get("publisherID").toString());
                    news_page_intent.putExtra("author", search.get(position).get("author").toString());
                    news_page_intent.putExtra("time", search.get(position).get("time").toString());
                    news_page_intent.putExtra("content", search.get(position).get("content").toString());
                    news_page_intent.putExtra("like_num", search.get(position).get("like_num").toString());
                    news_page_intent.putExtra("dislike_num", search.get(position).get("dislike_num").toString());
                    news_page_intent.putExtra("newsID", search.get(position).get("newsID").toString());
                    news_page_intent.putExtra("userID", userID);
                    startActivity(news_page_intent);
                }
            }
        });

        return view;
    }

    public void setUserID(String userID){
        this.userID = userID;
    }

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            Bundle data = msg.getData();
            String val = data.getString("returnType");
            Log.i("mylog", "请求结果为-->" + val);
            // UI界面的更新等相关操作
            if(val == "all"){
                typeAdapter.ls = news;
                flag = true;
            }else if(val == "search"){
                typeAdapter.ls = search;
                flag = false;
            }
            typeAdapter.notifyDataSetChanged();
        }
    };


    Runnable networkTask = new Runnable() {
        @Override
        public void run() {
            httpClient client = new httpClient();
            try {
                // news
                List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
                urlParameters.add(new BasicNameValuePair("posttype", "2"));//get all news
                news = client.NewsList("news", urlParameters);

                Message msg = new Message();
                Bundle data = new Bundle();
                data.putString("returnType", "all");
                msg.setData(data);
                handler.sendMessage(msg);
            }catch (Exception e) {
                System.out.println("Error:"+e);
            }
        }
    };

    Runnable runnable_search = new Runnable() {
        private  String keyword;

        public void setKeyword(String keyword) {
            this.keyword = keyword;
        }

        @Override
        public void run() {
            httpClient client = new httpClient();
            try {
                // news
                List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
                urlParameters.add(new BasicNameValuePair("posttype", "1"));
                urlParameters.add(new BasicNameValuePair("keyword", keyword));
                search = client.NewsList("news", urlParameters);

                Message msg = new Message();
                Bundle data = new Bundle();
                data.putString("returnType", "search");
                msg.setData(data);
                handler.sendMessage(msg);

            }catch (Exception e) {
                System.out.println("Error:"+e);
            }
        }
    };
}
